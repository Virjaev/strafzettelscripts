local ESX = exports['es_extended']:getSharedObject()

local activeFines = {}
local currentFine = nil
local lastReminder = 0

local function getCurrentUnixTime()
    -- FiveM-Client hat kein Lua "os".
    -- Diese Native liefert die aktuelle Unix-Zeit.
    return GetCloudTimeAsInt()
end

local function notify(message)
    ESX.ShowNotification(message)
end

RegisterNetEvent('esx_strafzettel:notify', function(message)
    notify(message)
end)

local function getNearbyVehicles()
    local coords = GetEntityCoords(PlayerPedId())
    local vehicles = GetGamePool('CVehicle')
    local output = {}

    for _, vehicle in ipairs(vehicles) do
        local distance = #(coords - GetEntityCoords(vehicle))

        if distance <= Config.SearchRadius then
            local vehicleName = GetLabelText(
                GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
            )

            output[#output + 1] = {
                plate = (GetVehicleNumberPlateText(vehicle) or '')
                    :gsub('^%s*(.-)%s*$', '%1'),

                name = vehicleName,

                distance = math.floor(distance * 10) / 10
            }
        end
    end

    table.sort(output, function(a, b)
        return a.distance < b.distance
    end)

    return output
end

RegisterNetEvent('esx_strafzettel:openPrinter', function()
    local vehicles = getNearbyVehicles()

    if #vehicles == 0 then
        return notify('Kein Fahrzeug in der Nähe gefunden.')
    end

    SetNuiFocus(true, true)

    SendNUIMessage({
        action = 'openPrinter',
        vehicles = vehicles
    })
end)

RegisterNUICallback('createFine', function(data, cb)
    TriggerServerEvent('esx_strafzettel:createFine', data)
    cb({ ok = true })
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb({ ok = true })
end)

RegisterNUICallback('payFine', function(data, cb)
    TriggerServerEvent('esx_strafzettel:payFine', data.id)
    cb({ ok = true })
end)

RegisterNUICallback('later', function(_, cb)
    SetNuiFocus(false, false)
    currentFine = nil
    cb({ ok = true })
end)

RegisterNetEvent('esx_strafzettel:printSuccess', function()
    SendNUIMessage({
        action = 'printing'
    })

    SetTimeout(3500, function()
        SetNuiFocus(false, false)

        SendNUIMessage({
            action = 'close'
        })
    end)
end)

local function showNextFine()
    currentFine = table.remove(activeFines, 1)

    if currentFine then
        SetNuiFocus(true, true)

        SendNUIMessage({
            action = 'showFine',
            fine = currentFine,
            now = getCurrentUnixTime()
        })
    end
end

RegisterNetEvent('esx_strafzettel:paid', function()
    SetNuiFocus(false, false)

    currentFine = nil

    SendNUIMessage({
        action = 'closeFine'
    })

    SetTimeout(300, function()
        showNextFine()
    end)
end)

local function checkDriverFines(vehicle)
    local plate = (GetVehicleNumberPlateText(vehicle) or '')
        :gsub('^%s*(.-)%s*$', '%1')

    ESX.TriggerServerCallback('esx_strafzettel:getOpenFines', function(fines)
        if fines and #fines > 0 then
            activeFines = fines
            showNextFine()
        end
    end, plate)
end

CreateThread(function()
    local wasDriver = false

    while true do
        Wait(500)

        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)

        local isDriver = vehicle ~= 0
            and GetPedInVehicleSeat(vehicle, -1) == ped

        if isDriver and not wasDriver then
            checkDriverFines(vehicle)
        end

        wasDriver = isDriver

        if isDriver
            and currentFine
            and GetGameTimer() - lastReminder > Config.ReminderInterval * 1000
        then
            lastReminder = GetGameTimer()

            local seconds = math.max(
                0,
                currentFine.due_at - getCurrentUnixTime()
            )

            TriggerEvent('chat:addMessage', {
                color = { 220, 50, 50 },
                multiline = true,
                args = {
                    'STRAFZETTEL',
                    ('Noch %02d:%02d:%02d Zeit zum Bezahlen.'):format(
                        math.floor(seconds / 3600),
                        math.floor((seconds % 3600) / 60),
                        math.floor(seconds % 60)
                    )
                }
            })
        end
    end
end)