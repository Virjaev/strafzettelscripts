local ESX = exports['es_extended']:getSharedObject()

local function trimPlate(plate)
    return (plate or ''):gsub('^%s*(.-)%s*$', '%1'):upper()
end

local function canPrint(xPlayer)
    return xPlayer
        and xPlayer.job
        and Config.AllowedJobs[xPlayer.job.name] == true
end

local function notify(source, message)
    TriggerClientEvent('esx:showNotification', source, message)
end

local function addMoneyToSociety(jobName, amount)
    local success = false

    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_' .. jobName, function(account)
        if account then
            account.addMoney(amount)
            success = true
        end
    end)

    return success
end

ESX.RegisterUsableItem(Config.PrinterItem, function(source)
    local xPlayer = ESX.GetPlayerFromId(source)

    if not canPrint(xPlayer) then
        return notify(
            source,
            'Du bist nicht berechtigt, den Mini-Drucker zu benutzen.'
        )
    end

    TriggerClientEvent('esx_strafzettel:openPrinter', source)
end)

ESX.RegisterServerCallback('esx_strafzettel:getVehicleOwner', function(source, cb, plate)
    local xPlayer = ESX.GetPlayerFromId(source)

    if not canPrint(xPlayer) then
        return cb(false)
    end

    plate = trimPlate(plate)

    local row = MySQL.single.await(
        'SELECT owner FROM owned_vehicles WHERE TRIM(plate) = ? LIMIT 1',
        { plate }
    )

    if not row then
        return cb(false)
    end

    cb({
        owner = row.owner,
        plate = plate
    })
end)

RegisterNetEvent('esx_strafzettel:createFine', function(payload)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

    if not canPrint(xPlayer) then
        return
    end

    if type(payload) ~= 'table' then
        return
    end

    local plate = trimPlate(payload.plate)
    local offence = tostring(payload.offence or ''):sub(1, 255)
    local amount = math.floor(tonumber(payload.amount) or 0)

    if plate == '' or offence == '' or amount < 1 or amount > 100000000 then
        return notify(
            source,
            'Bitte fülle Vergehen und einen gültigen Betrag aus.'
        )
    end

    local vehicle = MySQL.single.await(
        'SELECT owner FROM owned_vehicles WHERE TRIM(plate) = ? LIMIT 1',
        { plate }
    )

    if not vehicle then
        return notify(
            source,
            'Dieses Fahrzeug ist nicht als Privatfahrzeug registriert.'
        )
    end

    local now = os.time()

    local fineId = MySQL.insert.await([[
        INSERT INTO esx_vehicle_fines
        (
            owner_identifier,
            plate,
            offence,
            amount,
            issuer_name,
            issuer_job,
            issued_at,
            due_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ]], {
        vehicle.owner,
        plate,
        offence,
        amount,
        xPlayer.getName(),
        xPlayer.job.name,
        now,
        now + (Config.FineDueHours * 3600)
    })

    TriggerClientEvent('esx_strafzettel:printSuccess', source, fineId)

    notify(
        source,
        ('Strafzettel #%s wurde gedruckt.'):format(fineId)
    )
end)

ESX.RegisterServerCallback('esx_strafzettel:getOpenFines', function(source, cb, plate)
    local xPlayer = ESX.GetPlayerFromId(source)

    if not xPlayer then
        return cb({})
    end

    plate = trimPlate(plate)

    local fines = MySQL.query.await([[
        SELECT
            id,
            plate,
            offence,
            amount,
            issuer_name,
            issued_at,
            due_at
        FROM esx_vehicle_fines
        WHERE owner_identifier = ?
        AND plate = ?
        AND paid = 0
        ORDER BY issued_at ASC
    ]], {
        xPlayer.identifier,
        plate
    })

    cb(fines or {})
end)

RegisterNetEvent('esx_strafzettel:payFine', function(id)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

    id = tonumber(id)

    if not xPlayer or not id then
        return
    end

    local fine = MySQL.single.await([[
        SELECT *
        FROM esx_vehicle_fines
        WHERE id = ?
        AND owner_identifier = ?
        AND paid = 0
    ]], {
        id,
        xPlayer.identifier
    })

    if not fine then
        return notify(
            source,
            'Dieser Strafzettel wurde bereits bearbeitet.'
        )
    end

    -- Alte Strafzettel ohne Job gehen standardmäßig an die Polizei.
    local societyJob = fine.issuer_job or 'police'

    if not addMoneyToSociety(societyJob, fine.amount) then
        return notify(
            source,
            ('Das Firmenkonto society_%s wurde nicht gefunden.'):format(societyJob)
        )
    end

    -- Das Konto darf bewusst ins Minus gehen.
    local bank = xPlayer.getAccount('bank')

    xPlayer.setAccountMoney(
        'bank',
        bank.money - fine.amount,
        'vehicle_fine_payment'
    )

    MySQL.update.await([[
        UPDATE esx_vehicle_fines
        SET paid = 1, paid_at = ?
        WHERE id = ? AND paid = 0
    ]], {
        os.time(),
        id
    })

    TriggerClientEvent('esx_strafzettel:paid', source, id)

    notify(
        source,
        ('Strafzettel bezahlt: $%s'):format(fine.amount)
    )
end)

local function chargeOverdueFines(xPlayer)
    if not xPlayer then
        return
    end

    local now = os.time()

    local fines = MySQL.query.await([[
        SELECT *
        FROM esx_vehicle_fines
        WHERE owner_identifier = ?
        AND paid = 0
        AND due_at <= ?
    ]], {
        xPlayer.identifier,
        now
    })

    for _, fine in ipairs(fines or {}) do
        local charge = math.floor(fine.amount * 1.5 + 0.5)

        -- Alte Strafzettel ohne Job gehen standardmäßig an die Polizei.
        local societyJob = fine.issuer_job or 'police'

        if addMoneyToSociety(societyJob, charge) then
            local bank = xPlayer.getAccount('bank')

            xPlayer.setAccountMoney(
                'bank',
                bank.money - charge,
                'vehicle_fine_auto_charge'
            )

            MySQL.update.await([[
                UPDATE esx_vehicle_fines
                SET paid = 1,
                    paid_at = ?,
                    late_charged = 1
                WHERE id = ? AND paid = 0
            ]], {
                now,
                fine.id
            })

            notify(
                xPlayer.source,
                (
                    '~r~Strafzettel #%s wurde automatisch mit $%s bezahlt. ' ..
                    'Der Betrag ging an society_%s.'
                ):format(fine.id, charge, societyJob)
            )
        end
    end
end

RegisterNetEvent('esx_strafzettel:playerReady', function()
    chargeOverdueFines(ESX.GetPlayerFromId(source))
end)

CreateThread(function()
    while true do
        Wait(Config.AutoChargeInterval)

        for _, xPlayer in pairs(ESX.GetExtendedPlayers()) do
            chargeOverdueFines(xPlayer)
        end
    end
end)