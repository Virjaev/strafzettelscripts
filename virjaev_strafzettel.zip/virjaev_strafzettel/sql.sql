CREATE TABLE IF NOT EXISTS `esx_vehicle_fines` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `owner_identifier` VARCHAR(80) NOT NULL,
  `plate` VARCHAR(20) NOT NULL,
  `offence` VARCHAR(255) NOT NULL,
  `amount` INT NOT NULL,
  `issuer_identifier` VARCHAR(80) NOT NULL,
  `issuer_name` VARCHAR(100) NOT NULL,
  `issued_at` BIGINT NOT NULL,
  `due_at` BIGINT NOT NULL,
  `paid` TINYINT(1) NOT NULL DEFAULT 0,
  `paid_at` BIGINT NULL DEFAULT NULL,
  `late_charged` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `owner_open` (`owner_identifier`, `paid`),
  KEY `due_open` (`due_at`, `paid`),
  KEY `plate` (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE esx_vehicle_fines
ADD COLUMN issuer_job VARCHAR(50) NULL AFTER issuer_name;
