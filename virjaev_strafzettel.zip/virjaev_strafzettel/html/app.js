let selectedPlate = null;
let shownFine = null;

const post = (name, data = {}) =>
    fetch(`https://${GetParentResourceName()}/${name}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

const printer = document.querySelector('#printer');
const list = document.querySelector('#vehicle-list');
const form = document.querySelector('#form');
const printing = document.querySelector('#printing');
const fineBox = document.querySelector('#fine');

window.addEventListener('message', ({ data }) => {
    if (data.action === 'openPrinter') {
        printer.classList.remove('hidden');
        printer.classList.remove('is-printing');

        list.classList.remove('hidden');
        form.classList.add('hidden');
        printing.classList.add('hidden');

        list.innerHTML = '';

        data.vehicles.forEach((vehicle) => {
            const button = document.createElement('button');

            button.className = 'vehicle';

            const name =
                vehicle.name === 'NULL'
                    ? 'Unbekanntes Fahrzeug'
                    : vehicle.name;

            button.innerHTML = `
                <strong>${escapeHtml(name)}</strong>
                <span>${escapeHtml(vehicle.plate)} · ${vehicle.distance} m entfernt</span>
            `;

            button.addEventListener('click', () => {
                chooseVehicle(vehicle.plate);
            });

            list.appendChild(button);
        });
    }

    if (data.action === 'printing') {
        list.classList.add('hidden');
        form.classList.add('hidden');
        printing.classList.remove('hidden');

        printer.classList.add('is-printing');
    }

    if (data.action === 'close') {
        printer.classList.remove('is-printing');
        printer.classList.add('hidden');
    }

    if (data.action === 'showFine') {
        shownFine = data.fine;

        fineBox.classList.remove('hidden');

        fineBox.querySelector('.offence').textContent =
            data.fine.offence;

        fineBox.querySelector('.issuer').textContent =
            data.fine.issuer_name;

        fineBox.querySelector('.amount').textContent =
            '$' + Number(data.fine.amount).toLocaleString('de-DE');

        fineBox.querySelector('.due').textContent =
            new Date(data.fine.due_at * 1000).toLocaleString('de-DE');
    }

    if (data.action === 'closeFine') {
        fineBox.classList.add('hidden');
    }
});

function escapeHtml(text) {
    const element = document.createElement('div');
    element.textContent = text;
    return element.innerHTML;
}

function chooseVehicle(plate) {
    selectedPlate = plate;

    document.querySelector('#selected-plate').textContent = plate;

    list.classList.add('hidden');
    form.classList.remove('hidden');
}

function backToVehicles() {
    form.classList.add('hidden');
    list.classList.remove('hidden');
}

function closeUi() {
    printer.classList.remove('is-printing');
    printer.classList.add('hidden');

    post('close');
}

function submitFine() {
    const offence = document.querySelector('#offence').value.trim();
    const amount = document.querySelector('#amount').value;

    if (!offence || Number(amount) < 1) {
        return;
    }

    post('createFine', {
        plate: selectedPlate,
        offence: offence,
        amount: amount
    });
}

function payFine() {
    if (shownFine) {
        post('payFine', {
            id: shownFine.id
        });
    }
}

function later() {
    fineBox.classList.add('hidden');
    post('later');
}