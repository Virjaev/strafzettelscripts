fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Codex'
description 'Realistisches Strafzettel-System fuer ESX'
version '1.0.0'

shared_script 'config.lua'

client_scripts {
    '@es_extended/imports.lua',
    'client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js'
}

dependency 'es_extended'
dependency 'oxmysql'
