Config = {}

Config.AllowedJobs = {
    police = true,
    mechanic = true
}

Config.PrinterItem = 'minidrucker'
Config.SearchRadius = 18.0
Config.FineDueHours = 3
Config.LateFeeMultiplier = 1.50
Config.ReminderInterval = 60 -- Sekunden; Erinnerung beim Fahren
Config.AutoChargeInterval = 5 * 60 * 1000 -- alle 5 Minuten

Config.Locale = 'de'
